#!/usr/bin/env python3
"""
数据库抽象层
支持 SQLite 和 PostgreSQL
"""

import os
import sqlite3
from typing import Optional, Any, List, Tuple
from contextlib import contextmanager

# 检测使用哪个数据库
DB_TYPE = os.environ.get("PM_DB_TYPE", "sqlite").lower()

if DB_TYPE == "postgresql":
    try:
        import psycopg2
        import psycopg2.extras
        HAS_POSTGRESQL = True
    except ImportError:
        HAS_POSTGRESQL = False
        DB_TYPE = "sqlite"
else:
    HAS_POSTGRESQL = False


class DatabaseConnection:
    """数据库连接抽象类"""

    def __init__(self, db_path_or_dsn: str, timeout: float = 10.0):
        self.db_type = DB_TYPE
        self.db_path_or_dsn = db_path_or_dsn
        self.timeout = timeout
        self.conn = None

    def connect(self):
        """建立连接"""
        if self.db_type == "postgresql":
            self.conn = psycopg2.connect(
                self.db_path_or_dsn,
                connect_timeout=int(self.timeout)
            )
        else:
            self.conn = sqlite3.connect(
                self.db_path_or_dsn,
                timeout=self.timeout
            )
            self.conn.row_factory = sqlite3.Row
            # 设置 busy_timeout
            self.conn.execute(f"PRAGMA busy_timeout = {int(self.timeout * 1000)}")

        return self.conn

    def close(self):
        """关闭连接"""
        if self.conn:
            self.conn.close()
            self.conn = None

    def execute(self, query: str, params: Optional[Tuple] = None):
        """执行查询"""
        if not self.conn:
            self.connect()

        cur = self.conn.cursor()

        if self.db_type == "postgresql":
            # PostgreSQL 使用 %s 占位符
            query = query.replace("?", "%s")

        if params:
            cur.execute(query, params)
        else:
            cur.execute(query)

        return cur

    def fetchone(self, query: str, params: Optional[Tuple] = None):
        """获取单行"""
        cur = self.execute(query, params)
        return cur.fetchone()

    def fetchall(self, query: str, params: Optional[Tuple] = None):
        """获取所有行"""
        cur = self.execute(query, params)
        return cur.fetchall()

    def commit(self):
        """提交事务"""
        if self.conn:
            self.conn.commit()

    def rollback(self):
        """回滚事务"""
        if self.conn:
            self.conn.rollback()


@contextmanager
def get_db_connection(db_path_or_dsn: Optional[str] = None, timeout: float = 10.0):
    """获取数据库连接（上下文管理器）"""
    if db_path_or_dsn is None:
        # 默认使用 archive.db
        if DB_TYPE == "postgresql":
            db_path_or_dsn = os.environ.get(
                "PM_POSTGRESQL_DSN",
                "postgresql://xiong@localhost/weather_trading"
            )
        else:
            db_path_or_dsn = os.path.join(
                os.path.dirname(os.path.dirname(__file__)),
                "data",
                "archive.db"
            )

    db = DatabaseConnection(db_path_or_dsn, timeout)
    try:
        db.connect()
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def convert_sqlite_to_postgresql_schema(sqlite_schema: str) -> str:
    """将 SQLite schema 转换为 PostgreSQL schema"""
    pg_schema = sqlite_schema

    # 替换数据类型
    pg_schema = pg_schema.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "SERIAL PRIMARY KEY")
    pg_schema = pg_schema.replace("AUTOINCREMENT", "")
    pg_schema = pg_schema.replace("TEXT", "TEXT")
    pg_schema = pg_schema.replace("REAL", "DOUBLE PRECISION")
    pg_schema = pg_schema.replace("BLOB", "BYTEA")

    # 替换函数
    pg_schema = pg_schema.replace("datetime('now')", "NOW()")
    pg_schema = pg_schema.replace("date('now')", "CURRENT_DATE")

    return pg_schema


# 示例用法
if __name__ == "__main__":
    print(f"Database type: {DB_TYPE}")

    with get_db_connection() as db:
        result = db.fetchone("SELECT 1 as test")
        print(f"Connection test: {result}")
