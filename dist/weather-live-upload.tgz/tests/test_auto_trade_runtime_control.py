import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import ui.server as server


class AutoTradeRuntimeControlTests(unittest.TestCase):
    def test_build_auto_trade_criteria_pills_uses_config_for_signal_band_mode(self) -> None:
        payload = server.build_auto_trade_criteria_pills(
            {
                "entry_only_realizable": True,
                "lcb_global_enabled": True,
                "lcb_global_size_ratio": 0.35,
                "lcb_global_signal_lcb_min": 0.35,
                "lcb_global_path_lcb_min": 0.03,
                "lcb_global_edge_lcb_min": 0.0005,
                "lcb_global_plain_no_peak_exclude_min_price": 0.85,
                "lcb_global_signal_soft_band_mode": "small_live",
                "lcb_global_signal_soft_band_min": 0.25,
                "lcb_global_signal_soft_band_max": 0.35,
                "lcb_global_signal_soft_band_size_ratio": 0.35,
                "lcb_global_max_spread": 0.02,
                "lcb_global_min_depth_usdc": 10,
                "lcb_global_max_tick_age_sec": 90,
            }
        )
        sections = payload.get("sections") or []
        entry_pills = next(
            (
                section.get("pills")
                for section in sections
                if isinstance(section, dict) and str(section.get("id") or "") == "entry"
            ),
            [],
        )
        texts = [str(item.get("text") or "") for item in entry_pills if isinstance(item, dict)]
        self.assertTrue(any("signal_band=small_live" in text for text in texts))

    def test_hydrate_auto_trade_runtime_env_merges_repo_and_shared_env(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            repo_env = tmp_path / ".env"
            shared_env = tmp_path / "shared.env"
            repo_env.write_text(
                "\n".join(
                    [
                        "PM_AUTO_TRADE_ENABLED=1",
                        "PM_AUTO_TRADE_DRY_RUN=0",
                        "PM_AUTO_TRADE_SYNC_TRADES=1",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            shared_env.write_text(
                "\n".join(
                    [
                        "POLY_API_KEY=test-key",
                        "POLY_API_SECRET=test-secret",
                        "POLY_API_PASSPHRASE=test-passphrase",
                        "POLY_PRIVATE_KEY=0xabc123",
                        "PM_FUNDER_ADDRESS=0xfeedface",
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            with patch.object(server, "ENV_PATH", repo_env), patch.dict(
                os.environ,
                {"PM_SHARED_POLY_ENV_PATH": str(shared_env)},
                clear=False,
            ), patch.object(server, "_launchctl_getenv", return_value=""):
                for key in (
                    *server.AUTO_TRADE_CONTROL_ENV_KEYS,
                    *server.AUTO_TRADE_SHARED_ENV_KEYS,
                ):
                    os.environ.pop(key, None)
                server._hydrate_auto_trade_runtime_env()
                self.assertEqual(os.environ.get("PM_AUTO_TRADE_ENABLED"), "1")
                self.assertEqual(os.environ.get("PM_AUTO_TRADE_DRY_RUN"), "0")
                self.assertEqual(os.environ.get("POLY_API_KEY"), "test-key")
                self.assertEqual(os.environ.get("PRIVATE_KEY"), "0xabc123")
                self.assertEqual(os.environ.get("PM_FUNDER_ADDRESS"), "0xfeedface")

    def test_apply_auto_trade_state_persists_dry_run_and_restarts_runtime(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            repo_env = Path(tmpdir) / ".env"
            with patch.object(server, "ENV_PATH", repo_env), patch.object(
                server,
                "_restart_auto_trade_runtime_services",
                return_value={"ok": True, "results": []},
            ) as restart_mock, patch.object(server, "_launchctl_getenv", return_value=""):
                payload = server.apply_auto_trade_state(True, dry_run=False)
                self.assertTrue(payload["enabled"])
                self.assertFalse(payload["dry_run"])
                text = repo_env.read_text(encoding="utf-8")
                self.assertIn("PM_AUTO_TRADE_ENABLED=1", text)
                self.assertIn("PM_AUTO_TRADE_DRY_RUN=0", text)
                restart_mock.assert_called_once()


if __name__ == "__main__":
    unittest.main()
