import json
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import scan_weather_market as swm


class TestPriorityQMissing(unittest.TestCase):
    def test_priority_plan_prunes_stuck_no_quote_slug_when_last_success_precedes_fail(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc).replace(microsecond=0)
                run_date = now.date().isoformat()
                slug = "highest-temperature-in-stuck-city-on-test-date"
                success_text = (now - timedelta(minutes=120)).isoformat()
                fail_1 = (now - timedelta(minutes=20)).isoformat()
                fail_2 = (now - timedelta(minutes=10)).isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        1,
                        run_date,
                        slug,
                        run_date,
                        "Stuck City",
                        "10C",
                        "NO",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        fail_2,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO event_market_ticks(
                        run_date, event_date, slug, outcome, side, best_bid, best_ask, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        slug,
                        "10C",
                        "NO",
                        0.21,
                        0.22,
                        success_text,
                    ),
                )
                for created_at in (fail_1, fail_2):
                    cur.execute(
                        """
                        INSERT INTO scan_skips(slug, reason, created_at)
                        VALUES (?, ?, ?)
                        """,
                        (
                            slug,
                            "market_refresh_failed no_orderbook_quotes: synthetic test",
                            created_at,
                        ),
                    )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "10",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_WINDOW_MIN": "180",
                        "PM_SCAN_PRIORITY_NO_QUOTE_STUCK_WINDOW_MIN": "180",
                        "PM_SCAN_PRIORITY_NO_QUOTE_STUCK_MIN_FAILS": "2",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            self.assertIn(slug, list(plan.get("market_tick_stale_slugs") or []))
            self.assertIn(slug, list(plan.get("fixed_pruned_no_quote_slugs") or []))
            self.assertNotIn(slug, list(plan.get("fixed_slugs") or []))

    def test_priority_plan_keeps_no_quote_slug_when_success_arrives_after_failures(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc).replace(microsecond=0)
                run_date = now.date().isoformat()
                slug = "highest-temperature-in-recovered-city-on-test-date"
                fail_1 = (now - timedelta(minutes=20)).isoformat()
                fail_2 = (now - timedelta(minutes=10)).isoformat()
                success_text = (now - timedelta(minutes=5)).isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        1,
                        run_date,
                        slug,
                        run_date,
                        "Recovered City",
                        "11C",
                        "YES",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        success_text,
                    ),
                )
                for created_at in (fail_1, fail_2):
                    cur.execute(
                        """
                        INSERT INTO scan_skips(slug, reason, created_at)
                        VALUES (?, ?, ?)
                        """,
                        (
                            slug,
                            "market_refresh_failed no_orderbook_quotes: synthetic test",
                            created_at,
                        ),
                    )
                cur.execute(
                    """
                    INSERT INTO event_market_ticks(
                        run_date, event_date, slug, outcome, side, best_bid, best_ask, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        slug,
                        "11C",
                        "YES",
                        0.34,
                        0.35,
                        success_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "10",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_WINDOW_MIN": "180",
                        "PM_SCAN_PRIORITY_NO_QUOTE_STUCK_WINDOW_MIN": "180",
                        "PM_SCAN_PRIORITY_NO_QUOTE_STUCK_MIN_FAILS": "2",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            self.assertIn(slug, list(plan.get("market_tick_stale_slugs") or []))
            self.assertNotIn(slug, list(plan.get("fixed_pruned_no_quote_slugs") or []))
            self.assertIn(slug, list(plan.get("fixed_slugs") or []))

    def test_priority_plan_keeps_protected_position_and_open_order_when_no_quote_stuck(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc).replace(microsecond=0)
                run_date = now.date().isoformat()
                position_slug = "highest-temperature-in-position-city-on-test-date"
                open_order_slug = "highest-temperature-in-open-order-city-on-test-date"
                success_text = (now - timedelta(minutes=120)).isoformat()
                fail_1 = (now - timedelta(minutes=20)).isoformat()
                fail_2 = (now - timedelta(minutes=10)).isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO edge_trades(
                        slug, event_date, outcome, side, state, position_size, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        position_slug,
                        run_date,
                        "12C",
                        "NO",
                        "entry",
                        1.25,
                        now.isoformat(),
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO edge_trades(
                        slug, event_date, outcome, side, state, last_status, position_size, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        open_order_slug,
                        run_date,
                        "13C",
                        "YES",
                        "entry_pending",
                        "open_order_pending",
                        0.0,
                        now.isoformat(),
                    ),
                )
                for slug, outcome, side in (
                    (position_slug, "12C", "NO"),
                    (open_order_slug, "13C", "YES"),
                ):
                    cur.execute(
                        """
                        INSERT INTO event_market_ticks(
                            run_date, event_date, slug, outcome, side, best_bid, best_ask, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            run_date,
                            run_date,
                            slug,
                            outcome,
                            side,
                            0.25,
                            0.26,
                            success_text,
                        ),
                    )
                    for created_at in (fail_1, fail_2):
                        cur.execute(
                            """
                            INSERT INTO scan_skips(slug, reason, created_at)
                            VALUES (?, ?, ?)
                            """,
                            (
                                slug,
                                "market_refresh_failed no_orderbook_quotes: synthetic test",
                                created_at,
                            ),
                        )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_OPEN_ORDERS": "1",
                        "PM_SCAN_PRIORITY_NO_QUOTE_STUCK_WINDOW_MIN": "180",
                        "PM_SCAN_PRIORITY_NO_QUOTE_STUCK_MIN_FAILS": "2",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            fixed_slugs = list(plan.get("fixed_slugs") or [])
            pruned_slugs = list(plan.get("fixed_pruned_no_quote_slugs") or [])
            self.assertIn(position_slug, list(plan.get("position_slugs") or []))
            self.assertIn(open_order_slug, list(plan.get("open_order_slugs") or []))
            self.assertIn(position_slug, fixed_slugs)
            self.assertIn(open_order_slug, fixed_slugs)
            self.assertNotIn(position_slug, pruned_slugs)
            self.assertNotIn(open_order_slug, pruned_slugs)

    def test_priority_plan_includes_recent_market_tick_stale_entry_blockers(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                now_text = now.isoformat()
                stale_text = (now - timedelta(hours=2)).isoformat()
                run_date = now.date().isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        1,
                        run_date,
                        "highest-temperature-in-stale-city-on-test-date",
                        run_date,
                        "Stale City",
                        "10C",
                        "YES",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        now_text,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        2,
                        run_date,
                        "highest-temperature-in-old-stale-city-on-test-date",
                        run_date,
                        "Old Stale City",
                        "11C",
                        "NO",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        stale_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "10",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_WINDOW_MIN": "30",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            tick_stale_slugs = list(plan.get("market_tick_stale_slugs") or [])
            self.assertIn("highest-temperature-in-stale-city-on-test-date", tick_stale_slugs)
            self.assertNotIn("highest-temperature-in-old-stale-city-on-test-date", tick_stale_slugs)

    def test_recent_market_tick_stale_decision_outranks_global_stale_tail_when_capped(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                now_text = now.isoformat()
                decision_stale_text = (now - timedelta(hours=2)).isoformat()
                global_stale_text = (now - timedelta(hours=6)).isoformat()
                run_date = now.date().isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                for slug, tick_created_at in [
                    ("highest-temperature-in-decision-stale-city-on-test-date", decision_stale_text),
                    ("highest-temperature-in-global-stale-city-on-test-date", global_stale_text),
                ]:
                    cur.execute(
                        """
                        INSERT INTO event_market_ticks(
                            run_date, event_date, slug, outcome, side,
                            best_bid, best_ask, mid, spread,
                            bid_depth_topN, ask_depth_topN, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            run_date,
                            run_date,
                            slug,
                            "10C",
                            "YES",
                            0.39,
                            0.40,
                            0.395,
                            0.01,
                            100.0,
                            100.0,
                            tick_created_at,
                        ),
                    )
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        1,
                        run_date,
                        "highest-temperature-in-decision-stale-city-on-test-date",
                        run_date,
                        "Decision Stale City",
                        "10C",
                        "YES",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        now_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "0",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_MIN_AGE_SEC": "180",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_WINDOW_MIN": "30",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            tick_stale_slugs = list(plan.get("market_tick_stale_slugs") or [])
            self.assertEqual(
                tick_stale_slugs,
                ["highest-temperature-in-decision-stale-city-on-test-date"],
            )

    def test_latest_completed_run_market_tick_stale_outranks_older_window_hits(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                run_date = now.date().isoformat()
                older_run_started = (now - timedelta(minutes=10)).isoformat()
                older_run_ended = (now - timedelta(minutes=9)).isoformat()
                latest_run_started = (now - timedelta(minutes=2)).isoformat()
                latest_run_ended = (now - timedelta(minutes=1)).isoformat()
                tick_text = (now - timedelta(hours=2)).isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.executemany(
                    """
                    INSERT INTO auto_trade_runs(id, run_date, started_at, ended_at, ok, processed, skipped, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (1, run_date, older_run_started, older_run_ended, 1, 0, 0, older_run_started),
                        (2, run_date, latest_run_started, latest_run_ended, 1, 0, 0, latest_run_started),
                    ],
                )
                for slug in (
                    "highest-temperature-in-old-window-city-on-test-date",
                    "highest-temperature-in-latest-run-city-on-test-date",
                ):
                    cur.execute(
                        """
                        INSERT INTO event_market_ticks(
                            run_date, event_date, slug, outcome, side,
                            best_bid, best_ask, mid, spread,
                            bid_depth_topN, ask_depth_topN, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            run_date,
                            run_date,
                            slug,
                            "10C",
                            "YES",
                            0.39,
                            0.40,
                            0.395,
                            0.01,
                            100.0,
                            100.0,
                            tick_text,
                        ),
                    )
                for idx in range(5):
                    cur.execute(
                        """
                        INSERT INTO auto_trade_decisions(
                            run_id, run_date, slug, event_date, title, outcome, side, action,
                            decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            1,
                            run_date,
                            "highest-temperature-in-old-window-city-on-test-date",
                            run_date,
                            "Old Window City",
                            f"10C-{idx}",
                            "YES",
                            "entry",
                            "blocked",
                            0,
                            '["market_tick_stale"]',
                            '["tick stale"]',
                            "{}",
                            older_run_started,
                        ),
                    )
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        2,
                        run_date,
                        "highest-temperature-in-latest-run-city-on-test-date",
                        run_date,
                        "Latest Run City",
                        "10C",
                        "YES",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        latest_run_started,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "0",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_MIN_AGE_SEC": "180",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_WINDOW_MIN": "30",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            tick_stale_slugs = list(plan.get("market_tick_stale_slugs") or [])
            self.assertEqual(
                tick_stale_slugs,
                ["highest-temperature-in-latest-run-city-on-test-date"],
            )

    def test_market_tick_stale_priority_orders_tradeable_profit_first(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                run_date = now.date().isoformat()
                event_date = run_date
                latest_run_started = (now - timedelta(minutes=2)).isoformat()
                latest_run_ended = (now - timedelta(minutes=1)).isoformat()
                tick_text = (now - timedelta(hours=2)).isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO auto_trade_runs(id, run_date, started_at, ended_at, ok, processed, skipped, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (1, run_date, latest_run_started, latest_run_ended, 1, 0, 0, latest_run_started),
                )
                cases = [
                    (
                        "highest-temperature-in-low-profit-city-on-test-date",
                        5,
                        {"edge_tradeability_pass": True, "edge_tradeability_profit_value": 0.01},
                    ),
                    (
                        "highest-temperature-in-high-profit-city-on-test-date",
                        1,
                        {"edge_tradeability_pass": True, "edge_tradeability_profit_value": 0.12},
                    ),
                    (
                        "highest-temperature-in-blocked-profit-city-on-test-date",
                        1,
                        {"edge_tradeability_pass": False, "edge_tradeability_profit_value": 0.50},
                    ),
                ]
                for slug, hits, details in cases:
                    cur.execute(
                        """
                        INSERT INTO event_market_ticks(
                            run_date, event_date, slug, outcome, side,
                            best_bid, best_ask, mid, spread,
                            bid_depth_topN, ask_depth_topN, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            run_date,
                            event_date,
                            slug,
                            "10C",
                            "YES",
                            0.39,
                            0.40,
                            0.395,
                            0.01,
                            100.0,
                            100.0,
                            tick_text,
                        ),
                    )
                    for idx in range(hits):
                        cur.execute(
                            """
                            INSERT INTO auto_trade_decisions(
                                run_id, run_date, slug, event_date, title, outcome, side, action,
                                decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                1,
                                run_date,
                                slug,
                                event_date,
                                slug,
                                f"10C-{idx}",
                                "YES",
                                "entry",
                                "blocked",
                                0,
                                '["market_tick_stale"]',
                                '["tick stale"]',
                                json.dumps(details),
                                latest_run_started,
                            ),
                        )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "0",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "2",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_MIN_AGE_SEC": "180",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_WINDOW_MIN": "30",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            tick_stale_slugs = list(plan.get("market_tick_stale_slugs") or [])
            self.assertEqual(
                tick_stale_slugs,
                [
                    "highest-temperature-in-high-profit-city-on-test-date",
                    "highest-temperature-in-low-profit-city-on-test-date",
                ],
            )

    def test_latest_market_tick_stale_blocker_outranks_entry_ok_stale_when_capped(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                run_date = now.date().isoformat()
                event_date = run_date
                stale_tick_text = (now - timedelta(hours=2)).isoformat()
                latest_run_started = (now - timedelta(minutes=2)).isoformat()
                latest_run_ended = (now - timedelta(minutes=1)).isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO auto_trade_runs(id, run_date, started_at, ended_at, ok, processed, skipped, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (1, run_date, latest_run_started, latest_run_ended, 1, 0, 0, latest_run_started),
                )
                cur.execute(
                    """
                    CREATE TABLE event_fact_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        run_date TEXT NOT NULL,
                        slug TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        fact_as_of TEXT NOT NULL,
                        composer_version TEXT NOT NULL,
                        best_side TEXT,
                        best_outcome TEXT,
                        best_edge_score REAL,
                        fact_json TEXT NOT NULL,
                        created_at TEXT NOT NULL
                    )
                    """
                )
                cur.execute(
                    """
                    CREATE TABLE event_fact_latest (
                        slug TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        fact_id INTEGER NOT NULL,
                        updated_at TEXT NOT NULL,
                        PRIMARY KEY (slug, event_date)
                    )
                    """
                )
                for slug in (
                    "highest-temperature-in-entry-ok-city-on-test-date",
                    "highest-temperature-in-latest-blocker-city-on-test-date",
                ):
                    cur.execute(
                        """
                        INSERT INTO event_market_ticks(
                            run_date, event_date, slug, outcome, side,
                            best_bid, best_ask, mid, spread,
                            bid_depth_topN, ask_depth_topN, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            run_date,
                            event_date,
                            slug,
                            "10C",
                            "YES",
                            0.39,
                            0.40,
                            0.395,
                            0.01,
                            100.0,
                            100.0,
                            stale_tick_text,
                        ),
                    )
                fact_json = {
                    "run_date": run_date,
                    "event_date": event_date,
                    "market_top_label": "25C+",
                    "auto_trade_ssot": {
                        "main_candidate": {
                            "outcome": "24C",
                            "side": "NO",
                            "entry_ok": True,
                            "edge_score": 15.0,
                            "ask": 0.62,
                            "order_price": 0.62,
                        },
                        "main_entry_ok": True,
                    },
                }
                cur.execute(
                    """
                    INSERT INTO event_fact_history(
                        run_date, slug, event_date, fact_as_of,
                        composer_version, best_side, best_outcome, best_edge_score, fact_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        "highest-temperature-in-entry-ok-city-on-test-date",
                        event_date,
                        latest_run_started,
                        "test",
                        "NO",
                        "24C",
                        15.0,
                        json.dumps(fact_json),
                        latest_run_started,
                    ),
                )
                fact_id = cur.lastrowid
                cur.execute(
                    """
                    INSERT INTO event_fact_latest(slug, event_date, fact_id, updated_at)
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        "highest-temperature-in-entry-ok-city-on-test-date",
                        event_date,
                        fact_id,
                        latest_run_started,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        1,
                        run_date,
                        "highest-temperature-in-latest-blocker-city-on-test-date",
                        event_date,
                        "Latest Blocker City",
                        "10C",
                        "YES",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        latest_run_started,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_MIN_AGE_SEC": "180",
                        "PM_SCAN_PRIORITY_ENTRY_OK_TOPN": "10",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            tick_stale_slugs = list(plan.get("market_tick_stale_slugs") or [])
            self.assertEqual(
                tick_stale_slugs,
                ["highest-temperature-in-latest-blocker-city-on-test-date"],
            )

    def test_market_refresh_fast_mode_prefers_recent_decision_run_blockers(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                run_date = now.date().isoformat()
                older_started = (now - timedelta(minutes=20)).isoformat()
                older_ended = (now - timedelta(minutes=19)).isoformat()
                recent_text = (now - timedelta(seconds=20)).isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO auto_trade_runs(id, run_date, started_at, ended_at, ok, processed, skipped, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (1, run_date, older_started, older_ended, 1, 0, 0, older_started),
                )
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        1,
                        run_date,
                        "highest-temperature-in-old-completed-run-on-test-date",
                        run_date,
                        "Old Completed Run",
                        "10C",
                        "YES",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        older_started,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        2,
                        run_date,
                        "highest-temperature-in-recent-live-run-on-test-date",
                        run_date,
                        "Recent Live Run",
                        "11C",
                        "NO",
                        "entry",
                        "blocked",
                        0,
                        '["market_tick_stale"]',
                        '["tick stale"]',
                        "{}",
                        recent_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "0",
                        "PM_SCAN_PRIORITY_INCLUDE_Q_MISSING": "0",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "1",
                        "PM_SCAN_PRIORITY_TOPN": "1",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(
                        run_date,
                        args=SimpleNamespace(market_refresh_only=True),
                        max_events_per_run=1,
                    )

            self.assertEqual(
                list(plan.get("market_tick_stale_slugs") or []),
                ["highest-temperature-in-recent-live-run-on-test-date"],
            )

    def test_market_refresh_fast_mode_skips_nonfixed_when_stale_budget_is_full(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                run_date = now.date().isoformat()
                now_text = now.isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                for slug in (
                    "highest-temperature-in-stale-a-on-test-date",
                    "highest-temperature-in-stale-b-on-test-date",
                ):
                    cur.execute(
                        """
                        INSERT INTO auto_trade_decisions(
                            run_id, run_date, slug, event_date, title, outcome, side, action,
                            decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            2,
                            run_date,
                            slug,
                            run_date,
                            slug,
                            "10C",
                            "YES",
                            "entry",
                            "blocked",
                            0,
                            '["market_tick_stale"]',
                            '["tick stale"]',
                            "{}",
                            now_text,
                        ),
                    )
                cur.execute(
                    """
                    INSERT INTO auto_trade_decisions(
                        run_id, run_date, slug, event_date, title, outcome, side, action,
                        decided_state, will_order, reason_codes_json, reasons_json, details_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        3,
                        run_date,
                        "highest-temperature-in-q-missing-on-test-date",
                        run_date,
                        "Q Missing City",
                        "12C",
                        "YES",
                        "entry",
                        "blocked",
                        0,
                        '["q_missing"]',
                        '["q missing"]',
                        "{}",
                        now_text,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO event_runs(run_date, event_date, slug, title, suggestions_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        "highest-temperature-in-candidate-on-test-date",
                        "Candidate City",
                        json.dumps([{"edge_score": 12.0}]),
                        now_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "0",
                        "PM_SCAN_PRIORITY_INCLUDE_Q_MISSING": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "2",
                        "PM_SCAN_PRIORITY_Q_MISSING_TOPN": "2",
                        "PM_SCAN_PRIORITY_TOPN": "2",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(
                        run_date,
                        args=SimpleNamespace(market_refresh_only=True),
                        max_events_per_run=2,
                    )

            self.assertEqual(
                list(plan.get("market_tick_stale_slugs") or []),
                [
                    "highest-temperature-in-stale-a-on-test-date",
                    "highest-temperature-in-stale-b-on-test-date",
                ],
            )
            self.assertEqual(list(plan.get("candidate_slugs") or []), [])
            self.assertEqual(list(plan.get("q_missing_slugs") or []), [])

    def test_priority_plan_promotes_stale_entry_ok_tick_into_fixed(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                now_text = now.isoformat()
                stale_tick_text = (now - timedelta(hours=2)).isoformat()
                fresh_tick_text = (now - timedelta(seconds=30)).isoformat()
                run_date = now.date().isoformat()
                event_date = (now.date() + timedelta(days=1)).isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    CREATE TABLE event_fact_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        run_date TEXT NOT NULL,
                        slug TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        fact_as_of TEXT NOT NULL,
                        composer_version TEXT NOT NULL,
                        best_side TEXT,
                        best_outcome TEXT,
                        best_edge_score REAL,
                        fact_json TEXT NOT NULL,
                        created_at TEXT NOT NULL
                    )
                    """
                )
                cur.execute(
                    """
                    CREATE TABLE event_fact_latest (
                        slug TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        fact_id INTEGER NOT NULL,
                        updated_at TEXT NOT NULL,
                        PRIMARY KEY (slug, event_date)
                    )
                    """
                )
                for slug, created_at, tick_created_at in [
                    (
                        "highest-temperature-in-stale-entry-ok-city-on-test-date",
                        now_text,
                        stale_tick_text,
                    ),
                    (
                        "highest-temperature-in-fresh-entry-ok-city-on-test-date",
                        now_text,
                        fresh_tick_text,
                    ),
                ]:
                    fact_json = {
                        "run_date": run_date,
                        "event_date": event_date,
                        "market_top_label": "25C+",
                        "auto_trade_ssot": {
                            "main_candidate": {
                                "outcome": "24C",
                                "side": "NO",
                                "entry_ok": True,
                                "edge_score": 15.0,
                                "ask": 0.62,
                                "order_price": 0.62,
                            },
                            "main_entry_ok": True,
                        },
                    }
                    cur.execute(
                        """
                        INSERT INTO event_fact_history(
                            run_date, slug, event_date, fact_as_of,
                            composer_version, best_side, best_outcome, best_edge_score, fact_json, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            run_date,
                            slug,
                            event_date,
                            created_at,
                            "test",
                            "NO",
                            "24C",
                            15.0,
                            json.dumps(fact_json),
                            created_at,
                        ),
                    )
                    fact_id = cur.lastrowid
                    cur.execute(
                        """
                        INSERT INTO event_fact_latest(slug, event_date, fact_id, updated_at)
                        VALUES (?, ?, ?, ?)
                        """,
                        (slug, event_date, fact_id, created_at),
                    )
                    cur.execute(
                        """
                        INSERT INTO event_market_ticks(
                            run_date, event_date, slug, outcome, side,
                            best_bid, best_ask, mid, spread,
                            bid_depth_topN, ask_depth_topN, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            run_date,
                            event_date,
                            slug,
                            "24C",
                            "NO",
                            0.35,
                            0.36,
                            0.355,
                            0.01,
                            100.0,
                            100.0,
                            tick_created_at,
                        ),
                    )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_MARKET_TICK_STALE": "1",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_TOPN": "3",
                        "PM_SCAN_PRIORITY_MARKET_TICK_STALE_MIN_AGE_SEC": "180",
                        "PM_SCAN_PRIORITY_ENTRY_OK_TOPN": "10",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "1",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            tick_stale_slugs = list(plan.get("market_tick_stale_slugs") or [])
            fixed_slugs = list(plan.get("fixed_slugs") or [])
            self.assertIn("highest-temperature-in-stale-entry-ok-city-on-test-date", tick_stale_slugs)
            self.assertIn("highest-temperature-in-stale-entry-ok-city-on-test-date", fixed_slugs)
            self.assertNotIn("highest-temperature-in-fresh-entry-ok-city-on-test-date", tick_stale_slugs)

    def test_priority_plan_includes_recent_market_without_model_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now_text = datetime.now(timezone.utc).isoformat()
                run_date = datetime.now(timezone.utc).date().isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO market_snapshots(run_date, event_date, slug, payload_json, meta_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        "highest-temperature-in-test-city-on-test-date",
                        '{"slug":"highest-temperature-in-test-city-on-test-date","rows":[{"outcome":"10C","best_bid":0.4,"best_ask":0.42}]}',
                        '{"slug":"highest-temperature-in-test-city-on-test-date","title":"Test City"}',
                        now_text,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO market_snapshots(run_date, event_date, slug, payload_json, meta_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        "highest-temperature-in-modeled-city-on-test-date",
                        '{"slug":"highest-temperature-in-modeled-city-on-test-date","rows":[{"outcome":"11C","best_bid":0.3,"best_ask":0.31}]}',
                        '{"slug":"highest-temperature-in-modeled-city-on-test-date","title":"Modeled City"}',
                        now_text,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO model_snapshots(run_date, event_date, slug, payload_json, meta_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        "highest-temperature-in-modeled-city-on-test-date",
                        '{"slug":"highest-temperature-in-modeled-city-on-test-date","rows":[{"outcome":"11C","q_entry":0.4,"q_calibrated":0.41}]}',
                        '{"slug":"highest-temperature-in-modeled-city-on-test-date","title":"Modeled City"}',
                        now_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_Q_MISSING": "1",
                        "PM_SCAN_PRIORITY_Q_MISSING_TOPN": "10",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            q_missing_slugs = list(plan.get("q_missing_slugs") or [])
            self.assertIn("highest-temperature-in-test-city-on-test-date", q_missing_slugs)
            self.assertNotIn("highest-temperature-in-modeled-city-on-test-date", q_missing_slugs)

    def test_market_tick_stale_priority_survives_tail_reservation_when_capped(self) -> None:
        run_date = "2026-04-14"
        priority_plan = {
            "enabled": True,
            "ordered_slugs": [
                "stale-a",
                "stale-b",
                "tail-x",
                "tail-y",
                "candidate-z",
            ],
            "fixed_slugs": ["stale-a", "stale-b", "tail-x", "tail-y"],
            "candidate_slugs": ["candidate-z"],
            "market_tick_stale_slugs": ["stale-a", "stale-b"],
            "tail_slugs": ["tail-y", "tail-x"],
            "fixed_pruned_no_quote_slugs": [],
            "position_slugs": [],
            "open_order_slugs": [],
            "q_missing_slugs": [],
            "entry_ok_slugs": [],
            "event_stub_by_slug": {
                "stale-a": {"slug": "stale-a", "title": "stale-a", "endDate": run_date, "description": "", "resolutionSource": ""},
                "stale-b": {"slug": "stale-b", "title": "stale-b", "endDate": run_date, "description": "", "resolutionSource": ""},
                "tail-x": {"slug": "tail-x", "title": "tail-x", "endDate": run_date, "description": "", "resolutionSource": ""},
                "tail-y": {"slug": "tail-y", "title": "tail-y", "endDate": run_date, "description": "", "resolutionSource": ""},
                "candidate-z": {"slug": "candidate-z", "title": "candidate-z", "endDate": run_date, "description": "", "resolutionSource": ""},
            },
            "others_per_run": 0,
            "candidates_per_run": 1,
        }
        fake_events = [
            {"slug": "stale-a", "title": "stale-a", "endDate": run_date},
            {"slug": "stale-b", "title": "stale-b", "endDate": run_date},
            {"slug": "tail-x", "title": "tail-x", "endDate": run_date},
            {"slug": "tail-y", "title": "tail-y", "endDate": run_date},
            {"slug": "candidate-z", "title": "candidate-z", "endDate": run_date},
        ]
        args = [
            "scan_weather_market.py",
            "--scan-weather-today",
            "--market-refresh-only",
            "--days-ahead",
            "0",
            "--tz",
            "America/New_York",
        ]
        with (
            mock.patch("scan_weather_market.fetch_weather_events", return_value=(fake_events, [])),
            mock.patch("scan_weather_market._load_priority_scan_plan", return_value=priority_plan),
            mock.patch(
                "scan_weather_market.refresh_market_ticks_for_event",
                return_value=(True, None, 0, [], "2026-04-14T00:00:00+00:00"),
            ) as refresh_mock,
            mock.patch("scan_weather_market.save_market_snapshot"),
            mock.patch.dict(
                "os.environ",
                {
                    "PM_SCAN_PRIORITY_ENABLED": "1",
                    "PM_SCAN_MAX_EVENTS_PER_RUN": "4",
                    "PM_SCAN_MAX_MATCHED_PER_RUN": "4",
                    "PM_SCAN_PRIORITY_RESERVE_NONFIXED_SLOT": "1",
                    "PM_SCAN_PRIORITY_RESERVE_NONFIXED_SLOTS": "1",
                    "PM_SCAN_PRIORITY_RESERVE_TAIL_SLOT": "1",
                    "PM_SCAN_PRIORITY_RESERVE_TAIL_PREPEND": "1",
                    "PM_MARKET_REFRESH_COMPOSE_SCORE": "0",
                },
                clear=False,
            ),
            mock.patch("sys.argv", args),
        ):
            swm.main()

        called_slugs = [
            call.args[0]
            for call in refresh_mock.call_args_list
        ]
        self.assertIn("stale-a", called_slugs)
        self.assertIn("stale-b", called_slugs)

    def test_priority_plan_includes_recent_market_with_stale_model_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                now_text = now.isoformat()
                stale_text = (now - timedelta(hours=2)).isoformat()
                fresh_text = (now - timedelta(minutes=5)).isoformat()
                run_date = now.date().isoformat()
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO market_snapshots(run_date, event_date, slug, payload_json, meta_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        "highest-temperature-in-stale-model-city-on-test-date",
                        '{"slug":"highest-temperature-in-stale-model-city-on-test-date","rows":[{"outcome":"10C","best_bid":0.4,"best_ask":0.42}]}',
                        '{"slug":"highest-temperature-in-stale-model-city-on-test-date","title":"Stale Model City"}',
                        now_text,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO model_snapshots(run_date, event_date, slug, payload_json, meta_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        "highest-temperature-in-stale-model-city-on-test-date",
                        '{"slug":"highest-temperature-in-stale-model-city-on-test-date","rows":[{"outcome":"10C","q_entry":0.4,"q_calibrated":0.41}]}',
                        '{"slug":"highest-temperature-in-stale-model-city-on-test-date","title":"Stale Model City"}',
                        stale_text,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO market_snapshots(run_date, event_date, slug, payload_json, meta_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        "highest-temperature-in-fresh-model-city-on-test-date",
                        '{"slug":"highest-temperature-in-fresh-model-city-on-test-date","rows":[{"outcome":"11C","best_bid":0.3,"best_ask":0.31}]}',
                        '{"slug":"highest-temperature-in-fresh-model-city-on-test-date","title":"Fresh Model City"}',
                        now_text,
                    ),
                )
                cur.execute(
                    """
                    INSERT INTO model_snapshots(run_date, event_date, slug, payload_json, meta_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        run_date,
                        "highest-temperature-in-fresh-model-city-on-test-date",
                        '{"slug":"highest-temperature-in-fresh-model-city-on-test-date","rows":[{"outcome":"11C","q_entry":0.4,"q_calibrated":0.41}]}',
                        '{"slug":"highest-temperature-in-fresh-model-city-on-test-date","title":"Fresh Model City"}',
                        fresh_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_Q_MISSING": "1",
                        "PM_SCAN_PRIORITY_Q_MISSING_TOPN": "10",
                        "PM_SCAN_PRIORITY_Q_MISSING_WINDOW_MIN": "30",
                        "PM_SCAN_PRIORITY_Q_MISSING_MODEL_LAG_MIN": "30",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "0",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            q_missing_slugs = list(plan.get("q_missing_slugs") or [])
            self.assertIn("highest-temperature-in-stale-model-city-on-test-date", q_missing_slugs)
            self.assertNotIn("highest-temperature-in-fresh-model-city-on-test-date", q_missing_slugs)

    def test_priority_plan_skips_stale_plain_lcb_peak_entry_ok_fact(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                now_text = now.isoformat()
                run_date = now.date().isoformat()
                event_date = (now.date() + timedelta(days=1)).isoformat()
                fact_json = {
                    "run_date": run_date,
                    "event_date": event_date,
                    "market_top_label": "25C+",
                    "auto_trade_ssot": {
                        "main_candidate": {
                            "outcome": "25C+",
                            "side": "NO",
                            "entry_ok": True,
                            "edge_score": 15.0,
                            "ask": 0.95,
                            "order_price": 0.95,
                        },
                        "main_entry_ok": True,
                    },
                }
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    CREATE TABLE event_fact_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        run_date TEXT NOT NULL,
                        slug TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        fact_as_of TEXT NOT NULL,
                        composer_version TEXT NOT NULL,
                        best_side TEXT,
                        best_outcome TEXT,
                        best_edge_score REAL,
                        fact_json TEXT NOT NULL,
                        created_at TEXT NOT NULL
                    )
                    """
                )
                cur.execute(
                    """
                    CREATE TABLE event_fact_latest (
                        slug TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        fact_id INTEGER NOT NULL,
                        updated_at TEXT NOT NULL,
                        PRIMARY KEY (slug, event_date)
                    )
                    """
                )
                cur.execute(
                    """
                    INSERT INTO event_fact_history(
                        run_date, slug, event_date, fact_as_of,
                        composer_version, best_side, best_outcome, best_edge_score, fact_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        "highest-temperature-in-peak-city-on-test-date",
                        event_date,
                        now_text,
                        "test",
                        "NO",
                        "25C+",
                        15.0,
                        json.dumps(fact_json),
                        now_text,
                    ),
                )
                fact_id = cur.lastrowid
                cur.execute(
                    """
                    INSERT INTO event_fact_latest(slug, event_date, fact_id, updated_at)
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        "highest-temperature-in-peak-city-on-test-date",
                        event_date,
                        fact_id,
                        now_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "1",
                        "PM_SCAN_PRIORITY_ENTRY_OK_TOPN": "10",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "1",
                        "PM_LCB_GLOBAL_ENABLED": "1",
                        "PM_LCB_GLOBAL_PLAIN_NO_PEAK_EXCLUDE": "1",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            entry_ok_slugs = list(plan.get("entry_ok_slugs") or [])
            self.assertNotIn("highest-temperature-in-peak-city-on-test-date", entry_ok_slugs)

    def test_priority_plan_keeps_non_peak_entry_ok_fact(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "archive.db"
            with mock.patch.object(swm, "DB_PATH", db_path):
                swm.init_db()
                now = datetime.now(timezone.utc)
                now_text = now.isoformat()
                run_date = now.date().isoformat()
                event_date = (now.date() + timedelta(days=1)).isoformat()
                fact_json = {
                    "run_date": run_date,
                    "event_date": event_date,
                    "market_top_label": "25C+",
                    "auto_trade_ssot": {
                        "main_candidate": {
                            "outcome": "24C",
                            "side": "NO",
                            "entry_ok": True,
                            "edge_score": 15.0,
                            "ask": 0.62,
                            "order_price": 0.62,
                        },
                        "main_entry_ok": True,
                    },
                }
                conn = sqlite3.connect(db_path)
                cur = conn.cursor()
                cur.execute(
                    """
                    CREATE TABLE event_fact_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        run_date TEXT NOT NULL,
                        slug TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        fact_as_of TEXT NOT NULL,
                        composer_version TEXT NOT NULL,
                        best_side TEXT,
                        best_outcome TEXT,
                        best_edge_score REAL,
                        fact_json TEXT NOT NULL,
                        created_at TEXT NOT NULL
                    )
                    """
                )
                cur.execute(
                    """
                    CREATE TABLE event_fact_latest (
                        slug TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        fact_id INTEGER NOT NULL,
                        updated_at TEXT NOT NULL,
                        PRIMARY KEY (slug, event_date)
                    )
                    """
                )
                cur.execute(
                    """
                    INSERT INTO event_fact_history(
                        run_date, slug, event_date, fact_as_of,
                        composer_version, best_side, best_outcome, best_edge_score, fact_json, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_date,
                        "highest-temperature-in-non-peak-city-on-test-date",
                        event_date,
                        now_text,
                        "test",
                        "NO",
                        "24C",
                        15.0,
                        json.dumps(fact_json),
                        now_text,
                    ),
                )
                fact_id = cur.lastrowid
                cur.execute(
                    """
                    INSERT INTO event_fact_latest(slug, event_date, fact_id, updated_at)
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        "highest-temperature-in-non-peak-city-on-test-date",
                        event_date,
                        fact_id,
                        now_text,
                    ),
                )
                conn.commit()
                conn.close()

                with mock.patch.dict(
                    "os.environ",
                    {
                        "PM_SCAN_PRIORITY_ENABLED": "1",
                        "PM_SCAN_PRIORITY_INCLUDE_ENTRY_OK": "1",
                        "PM_SCAN_PRIORITY_ENTRY_OK_TOPN": "10",
                        "PM_SCAN_PRIORITY_TOPN": "10",
                        "PM_SCAN_PRIORITY_LOOKAHEAD_DAYS": "1",
                        "PM_LCB_GLOBAL_ENABLED": "1",
                        "PM_LCB_GLOBAL_PLAIN_NO_PEAK_EXCLUDE": "1",
                        "PM_LCB_GLOBAL_PLAIN_NO_PEAK_EXCLUDE_MIN_PRICE": "0.70",
                    },
                    clear=False,
                ):
                    plan = swm._load_priority_scan_plan(run_date)

            entry_ok_slugs = list(plan.get("entry_ok_slugs") or [])
            self.assertIn("highest-temperature-in-non-peak-city-on-test-date", entry_ok_slugs)


if __name__ == "__main__":
    unittest.main()
