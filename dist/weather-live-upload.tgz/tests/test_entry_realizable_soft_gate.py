import unittest

import scan_weather_market as swm


class EntryRealizableSoftGateTests(unittest.TestCase):
    def test_missing_realizable_is_soft_when_tradeability_exists(self) -> None:
        candidate = {
            "edge_tradeability_blocked": True,
            "edge_tradeability_reasons": "signal_lcb_below_min",
            "edge_signal_lcb": 0.12,
            "edge_path_p_reach_lcb": 0.25,
            "edge_tradeability_profit_value": -0.001,
            "edge_tradeability_profit_min": 0.0005,
        }
        blocked = swm._entry_realizable_only_block_detail(
            candidate,
            min_edge_realizable=0.0,
        )
        self.assertIsNone(blocked)
        self.assertTrue(candidate["edge_realizable_soft_blocked"])
        self.assertEqual(candidate["edge_realizable_soft_block_reason"], "tradeability_available")

    def test_nonpositive_realizable_is_soft_diagnostic(self) -> None:
        candidate = {
            "edge_realizable": 0.0,
            "edge_tradeability_blocked": True,
            "edge_tradeability_reasons": "signal_lcb_below_min",
            "edge_tradeability_profit_value": -0.001,
            "edge_tradeability_profit_min": 0.0005,
        }
        blocked = swm._entry_realizable_only_block_detail(
            candidate,
            min_edge_realizable=0.0,
        )
        self.assertIsNone(blocked)
        self.assertTrue(candidate["edge_realizable_soft_blocked"])
        self.assertEqual(candidate["edge_realizable_soft_block_reason"], "entry_only_realizable")

    def test_missing_realizable_still_blocks_when_tradeability_missing(self) -> None:
        blocked = swm._entry_realizable_only_block_detail(
            {},
            min_edge_realizable=0.0,
        )
        self.assertIsNotNone(blocked)
        reason_code, reason_text, details = blocked
        self.assertEqual(reason_code, "edge_realizable_missing")
        self.assertEqual(reason_text, "可兑现口径缺失(edge_realizable)")
        self.assertFalse(details["edge_tradeability_available"])


if __name__ == "__main__":
    unittest.main()
