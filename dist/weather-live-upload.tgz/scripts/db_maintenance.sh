#!/bin/bash
# 数据库定期维护脚本
# 建议每周运行一次

set -e

DB_PATH="/Users/xiong/weather/data/archive.db"
LOG_PATH="/Users/xiong/weather/data/logs/db_maintenance.log"

echo "[$(date)] 开始数据库维护..." | tee -a "$LOG_PATH"

# 1. 清理旧的market_ticks（保留7天）
echo "清理旧market_ticks..." | tee -a "$LOG_PATH"
sqlite3 "$DB_PATH" "DELETE FROM event_market_ticks WHERE run_date < date('now', '-7 days');"

# 2. 清理旧的event_runs（保留30天）
echo "清理旧event_runs..." | tee -a "$LOG_PATH"
sqlite3 "$DB_PATH" "DELETE FROM event_runs WHERE run_date < date('now', '-30 days');"

# 3. 清理旧的model_snapshots（保留30天）
echo "清理旧model_snapshots..." | tee -a "$LOG_PATH"
sqlite3 "$DB_PATH" "DELETE FROM model_snapshots WHERE created_at < datetime('now', '-30 days');"

# 4. 优化数据库
echo "优化数据库..." | tee -a "$LOG_PATH"
sqlite3 "$DB_PATH" "PRAGMA optimize;"

# 5. 统计信息
RECORDS=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM event_market_ticks;")
SIZE=$(du -h "$DB_PATH" | cut -f1)
echo "维护完成 - 记录数: $RECORDS, 文件大小: $SIZE" | tee -a "$LOG_PATH"
