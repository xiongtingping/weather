#!/bin/bash
set -euo pipefail

ROOT="/Users/xiong/weather"
cd "$ROOT"

echo "=== 定期数据清理脚本 ==="
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 1. 清理30天前的历史数据
echo "【清理历史数据】"
sqlite3 data/archive.db << 'EOF'
DELETE FROM event_runs WHERE created_at < datetime('now', '-30 days');
DELETE FROM event_fact_history WHERE fact_as_of < datetime('now', '-30 days');
DELETE FROM auto_trade_decisions WHERE created_at < datetime('now', '-30 days');
DELETE FROM market_snapshots WHERE created_at < datetime('now', '-30 days');
DELETE FROM event_market_ticks WHERE created_at < datetime('now', '-7 days');
DELETE FROM model_snapshots WHERE created_at < datetime('now', '-30 days');

SELECT 'Deleted rows:' as info;
SELECT changes() as deleted_rows;
EOF
echo "✅ 历史数据清理完成"
echo ""

# 2. 压缩数据库
echo "【压缩数据库】"
sqlite3 data/archive.db "PRAGMA wal_checkpoint(TRUNCATE); VACUUM; ANALYZE;"
echo "✅ 数据库优化完成"
echo ""

# 3. 清理日志文件
echo "【清理日志文件】"
LOG_COUNT=$(find data/logs -name "*.log" -mtime +7 2>/dev/null | wc -l)
if [ "$LOG_COUNT" -gt 0 ]; then
  find data/logs -name "*.log" -mtime +7 -delete 2>/dev/null || true
  echo "✅ 删除 $LOG_COUNT 个7天前的日志文件"
else
  echo "没有需要清理的日志文件"
fi
echo ""

# 4. 清理缓存文件
echo "【清理缓存文件】"
rm -f data/weather_events_cache.json data/weather_events_cache.good.json
echo "✅ 缓存文件已清理"
echo ""

# 5. 显示清理结果
echo "【清理后】"
du -sh data/archive.db
echo ""

echo "=== 清理完成 ==="
