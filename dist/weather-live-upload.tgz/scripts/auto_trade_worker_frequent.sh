#!/bin/bash
set -euo pipefail

ROOT="/Users/xiong/weather"
cd "$ROOT"

# 加载环境变量
if [ -f "$ROOT/.env" ]; then
  set -a
  . "$ROOT/.env"
  set +a
fi

LOG="$ROOT/data/auto_trade_worker_frequent.log"

PM_AUTO_TRADE_EVENT_TIMEOUT_CAP_SEC="${PM_AUTO_TRADE_EVENT_TIMEOUT_CAP_SEC:-45}"
if ! [[ "${PM_AUTO_TRADE_EVENT_TIMEOUT_CAP_SEC}" =~ ^[0-9]+$ ]] || [ "${PM_AUTO_TRADE_EVENT_TIMEOUT_CAP_SEC}" -lt 5 ]; then
  PM_AUTO_TRADE_EVENT_TIMEOUT_CAP_SEC=45
fi
export PM_AUTO_TRADE_EVENT_TIMEOUT_SEC="${PM_AUTO_TRADE_EVENT_TIMEOUT_SEC:-${PM_AUTO_TRADE_EVENT_TIMEOUT_CAP_SEC}}"
if ! [[ "${PM_AUTO_TRADE_EVENT_TIMEOUT_SEC}" =~ ^[0-9]+$ ]] || [ "${PM_AUTO_TRADE_EVENT_TIMEOUT_SEC}" -lt 1 ] || [ "${PM_AUTO_TRADE_EVENT_TIMEOUT_SEC}" -gt "${PM_AUTO_TRADE_EVENT_TIMEOUT_CAP_SEC}" ]; then
  PM_AUTO_TRADE_EVENT_TIMEOUT_SEC="${PM_AUTO_TRADE_EVENT_TIMEOUT_CAP_SEC}"
fi

echo "---- $(date '+%Y-%m-%d %H:%M:%S') auto_trade_worker_frequent start ----" >> "$LOG"

# 运行一次 auto-trade job worker
# 处理队列中的交易任务
.venv/bin/python scan_weather_market.py \
  --auto-trade-job-worker \
  --once \
  >> "$LOG" 2>&1

exit_code=$?
echo "$(date '+%Y-%m-%d %H:%M:%S') [auto_trade_worker_frequent] completed exit=$exit_code" >> "$LOG"
exit $exit_code
