#!/bin/bash
set -euo pipefail

ROOT="/Users/xiong/weather"
cd "$ROOT"

# 加载环境变量
if [ -f "$ROOT/.env" ]; then
  set -a
  . "$ROOT/.env"
  set +a
fi

# 加载全局扫描锁
. "$ROOT/scripts/lib/acquire_scan_lock.sh"

LOG="$ROOT/data/model_scan_hourly.log"

# 获取扫描锁（不等待，如果有其他扫描在运行就跳过）
if ! acquire_scan_lock "model_scan_hourly" 0; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') [model_scan_hourly] skipped (another scan is running)" >> "$LOG"
  exit 0
fi

echo "---- $(date '+%Y-%m-%d %H:%M:%S') model_scan_hourly start ----" >> "$LOG"

# 只扫描优先级高的事件（有持仓、有挂单、edge_lcb高的）
# 限制最多10个事件，避免API限流
# 注意：移除了 --no-auto-trade 以允许生成 q 值预测
.venv/bin/python scan_weather_market.py \
  --scan-weather-today \
  --days-ahead 2 \
  --model-refresh-only \
  --ensemble-models gfs_seamless,icon_seamless,nws_forecast \
  --depth-levels 5 \
  >> "$LOG" 2>&1

exit_code=$?
echo "$(date '+%Y-%m-%d %H:%M:%S') [model_scan_hourly] completed exit=$exit_code" >> "$LOG"
exit $exit_code
