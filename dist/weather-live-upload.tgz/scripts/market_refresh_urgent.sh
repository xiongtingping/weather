#!/bin/bash
set -euo pipefail

ROOT="/Users/xiong/weather"
cd "$ROOT"

# 加载环境变量
if [ -f "$ROOT/.env" ]; then
  set -a
  . "$ROOT/.env"
  set +a
fi

LOG="$ROOT/data/market_refresh_urgent.log"

# 查询距离结算<8小时的事件数量（临近结算加速）
URGENT_COUNT=$(sqlite3 data/archive.db "SELECT COUNT(*) FROM event_fact_latest WHERE event_date > datetime('now') AND (julianday(event_date) - julianday('now')) * 24 < 8;")

if [ "$URGENT_COUNT" -eq 0 ]; then
  # 没有紧急事件，跳过
  exit 0
fi

echo "$(date '+%Y-%m-%d %H:%M:%S') [urgent_refresh] urgent events: $URGENT_COUNT" >> "$LOG"

# 只刷新临近结算的事件（<8小时）
# 限制最多20个事件，25秒预算
# 增加超时和重试：5秒超时，3次重试
.venv/bin/python scan_weather_market.py \
  --scan-weather-today \
  --market-refresh-only \
  --market-refresh-max-outcomes 20 \
  --market-refresh-time-budget-sec 25 \
  --market-refresh-clob-timeout-sec 5 \
  --market-refresh-clob-retries 3 \
  --no-auto-trade \
  >> "$LOG" 2>&1

exit_code=$?
echo "$(date '+%Y-%m-%d %H:%M:%S') [urgent_refresh] completed exit=$exit_code" >> "$LOG"
exit $exit_code
