#!/bin/bash
#
# edge_realizable 校准模型自动训练调度脚本
#
# 功能：
# 1. 检查数据量是否足够
# 2. 训练新模型
# 3. 验证模型质量
# 4. 自动部署
# 5. 发送通知
#
# 使用：
#   ./auto_train_edge_realizable.sh [--force]

set -e

# 配置
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
DB_PATH="$PROJECT_DIR/data/archive.db"
OUTPUT_PATH="$PROJECT_DIR/data/edge_realizable_calibration.json"
LOG_DIR="$PROJECT_DIR/logs"
LOG_FILE="$LOG_DIR/edge_realizable_training_$(date +%Y%m%d_%H%M%S).log"

# 参数
MIN_SAMPLES=100
TRAINING_DAYS=90
FORCE=false

# 解析参数
while [[ $# -gt 0 ]]; do
  case $1 in
    --force)
      FORCE=true
      shift
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

# 创建日志目录
mkdir -p "$LOG_DIR"

# 日志函数
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

log "========================================="
log "edge_realizable 校准模型自动训练"
log "========================================="

# 1. 检查数据量
log "检查数据量..."
TRADE_COUNT=$(sqlite3 "$DB_PATH" "
SELECT COUNT(*)
FROM edge_trades
WHERE entry_at > datetime('now', '-$TRAINING_DAYS days')
  AND state IN ('settled', 'exited', 'stopped')
")

log "  历史交易数: $TRADE_COUNT"

if [ "$TRADE_COUNT" -lt "$MIN_SAMPLES" ] && [ "$FORCE" = false ]; then
  log "Warning: 数据量不足 ($TRADE_COUNT < $MIN_SAMPLES)"
  log "  建议等待更多数据积累后再训练"
  log "  或使用 --force 强制训练"
  exit 0
fi

# 2. 训练模型
log "开始训练模型..."
python3 "$SCRIPT_DIR/train_edge_realizable_calibration.py" \
  --days "$TRAINING_DAYS" \
  --min-samples 20 \
  --db "$DB_PATH" \
  --output "$OUTPUT_PATH" \
  2>&1 | tee -a "$LOG_FILE"

if [ $? -ne 0 ]; then
  log "Error: 训练失败"
  exit 1
fi

# 3. 验证模型
log "验证模型..."
if [ ! -f "$OUTPUT_PATH" ]; then
  log "Error: 输出文件不存在"
  exit 1
fi

# 检查 JSON 格式
if ! python3 -c "import json; json.load(open('$OUTPUT_PATH'))" 2>/dev/null; then
  log "Error: 输出文件格式错误"
  exit 1
fi

# 提取关键指标
SAMPLE_N=$(python3 -c "import json; print(json.load(open('$OUTPUT_PATH'))['sample_n'])")
P_FILL=$(python3 -c "import json; print(json.load(open('$OUTPUT_PATH'))['p_fill_entry_default'])")
P_CONV=$(python3 -c "import json; print(json.load(open('$OUTPUT_PATH'))['p_converge_default'])")
BUCKETS=$(python3 -c "import json; print(len(json.load(open('$OUTPUT_PATH'))['p_fill_entry_buckets']))")

log "  样本数: $SAMPLE_N"
log "  p_fill_entry: $P_FILL"
log "  p_converge: $P_CONV"
log "  buckets: $BUCKETS"

# 合理性检查
if (( $(echo "$P_FILL < 0.3 || $P_FILL > 0.95" | bc -l) )); then
  log "Warning: p_fill_entry 异常 ($P_FILL)"
fi

if (( $(echo "$P_CONV < 0.3 || $P_CONV > 0.95" | bc -l) )); then
  log "Warning: p_converge 异常 ($P_CONV)"
fi

# 4. 重启服务（使新模型生效）
log "重启交易引擎..."
if launchctl list | grep -q "com.weather.trade_engine"; then
  launchctl stop com.weather.trade_engine
  sleep 2
  launchctl start com.weather.trade_engine
  log "  服务已重启"
else
  log "  服务未运行，跳过重启"
fi

# 5. 生成报告
REPORT_PATH="$PROJECT_DIR/EDGE_REALIZABLE_TRAINING_REPORT_$(date +%Y%m%d).md"
cat > "$REPORT_PATH" << EOF
# edge_realizable 校准模型训练报告

## 训练时间
$(date '+%Y-%m-%d %H:%M:%S')

## 数据统计

- **训练窗口**: $TRAINING_DAYS 天
- **样本数**: $SAMPLE_N
- **buckets 数量**: $BUCKETS

## 模型参数

### 全局默认值

- **p_fill_entry_default**: $P_FILL
- **p_converge_default**: $P_CONV
- **p_fill_exit_default**: $P_FILL
- **p_realize**: $(echo "$P_FILL * $P_CONV * $P_FILL" | bc -l | xargs printf "%.4f")

### 解释

- **p_fill_entry**: 订单成交概率（$P_FILL = $(echo "$P_FILL * 100" | bc -l | xargs printf "%.1f")%）
- **p_converge**: 价格收敛/盈利概率（$P_CONV = $(echo "$P_CONV * 100" | bc -l | xargs printf "%.1f")%）
- **p_realize**: 整体成功概率（$(echo "$P_FILL * $P_CONV * $P_FILL * 100" | bc -l | xargs printf "%.1f")%）

## 部署状态

✅ 模型已训练
✅ 文件已保存: $OUTPUT_PATH
✅ 服务已重启

## 下次训练

建议 7 天后重新训练（$(date -v+7d '+%Y-%m-%d')）

---

**日志文件**: $LOG_FILE
EOF

log "报告已生成: $REPORT_PATH"

# 6. 清理旧备份（保留最近10个）
log "清理旧备份..."
ls -t "$PROJECT_DIR/data/edge_realizable_calibration."*.bak 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null || true

log "========================================="
log "训练完成！"
log "========================================="
