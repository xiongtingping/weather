#!/bin/bash
# 监控worker健康状态

LOCK_DIR="/Users/xiong/weather/data/auto_trade_runtime.lock"
MAX_LOCK_AGE_MIN=5
MAX_WORKER_RUNTIME_MIN=10

echo "=== Worker Health Monitor ==="
echo "Time: $(date -u)"
echo ""

# 检查lock年龄
if [ -d "$LOCK_DIR" ]; then
    LOCK_AGE_MIN=$(find "$LOCK_DIR" -type d -mmin +${MAX_LOCK_AGE_MIN} | wc -l | tr -d ' ')
    if [ "$LOCK_AGE_MIN" -gt 0 ]; then
        echo "🔴 ALERT: Lock is stale (>${MAX_LOCK_AGE_MIN} min)"
        echo "   Cleaning up..."
        rm -rf "$LOCK_DIR"
        echo "   ✅ Lock cleaned"
    else
        echo "✅ Lock age OK (<${MAX_LOCK_AGE_MIN} min)"
    fi
else
    echo "✅ No lock exists"
fi

echo ""

# 检查worker进程
STUCK_WORKERS=$(ps aux | grep auto_trade_job_worker | grep -v grep | awk -v max=$MAX_WORKER_RUNTIME_MIN '{
    split($10, time, ":");
    if (length(time) == 2) {
        runtime = time[1] * 60 + time[2];
    } else if (length(time) == 3) {
        runtime = time[1] * 3600 + time[2] * 60 + time[3];
    } else {
        runtime = 0;
    }
    if (runtime > max * 60) {
        print $2, runtime/60 "min";
    }
}')

if [ -n "$STUCK_WORKERS" ]; then
    echo "🔴 ALERT: Stuck workers detected:"
    echo "$STUCK_WORKERS" | while read pid runtime; do
        echo "   PID $pid running for $runtime"
        echo "   Killing..."
        kill -9 $pid 2>/dev/null
        echo "   ✅ Killed"
    done
else
    echo "✅ No stuck workers"
fi

echo ""

# 检查任务失败率
FAILED_RATE=$(sqlite3 /Users/xiong/weather/data/archive.db "
SELECT ROUND(
    SUM(CASE WHEN state IN ('failed', 'retrying') THEN 1 ELSE 0 END) * 100.0 / COUNT(*),
    1
)
FROM auto_trade_jobs
WHERE created_at >= datetime('now', '-1 hour')
")

echo "Task failure rate (last hour): ${FAILED_RATE}%"
if [ $(echo "$FAILED_RATE > 10" | bc) -eq 1 ]; then
    echo "🔴 ALERT: High failure rate (>${FAILED_RATE}%)"
else
    echo "✅ Failure rate OK"
fi

echo ""
echo "=== End of Health Check ==="
