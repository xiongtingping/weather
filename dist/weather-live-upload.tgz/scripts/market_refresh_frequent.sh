#!/bin/bash
set -euo pipefail

ROOT="/Users/xiong/weather"
cd "$ROOT"

# 加载环境变量
if [ -f "$ROOT/.env" ]; then
  set -a
  . "$ROOT/.env"
  set +a
fi

# 加载全局扫描锁
. "$ROOT/scripts/lib/acquire_scan_lock.sh"

LOG="$ROOT/data/market_refresh_frequent.log"

# 获取扫描锁（不等待，如果有其他扫描在运行就跳过）
if ! acquire_scan_lock "market_refresh_frequent" 0; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') [market_refresh_frequent] skipped (another scan is running)" >> "$LOG"
  exit 0
fi

echo "---- $(date '+%Y-%m-%d %H:%M:%S') market_refresh_frequent start ----" >> "$LOG"

# 只刷新市场数据，不更新模型预测
# 针对有持仓或高edge的事件
.venv/bin/python scan_weather_market.py \
  --scan-weather-today \
  --days-ahead 2 \
  --market-refresh-only \
  --depth-levels 5 \
  >> "$LOG" 2>&1

exit_code=$?
echo "$(date '+%Y-%m-%d %H:%M:%S') [market_refresh_frequent] completed exit=$exit_code" >> "$LOG"
exit $exit_code
